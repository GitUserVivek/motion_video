# Install script for directory: /kaggle/working/motion_video/node_modules/node-llama-cpp/llama/llama.cpp/ggml

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/usr/local")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "1")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

# Set path to fallback-tool for dependency-resolution.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/usr/bin/objdump")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for the subdirectory.
  include("/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/localBuilds/linux-x64-cuda-6u553c5r6wgv6uc3b523w6g491l48j5j5z53/llama.cpp/ggml/src/cmake_install.cmake")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libggml.cuda.v0.9.0.6u553c5r.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libggml.cuda.v0.9.0.6u553c5r.so")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libggml.cuda.v0.9.0.6u553c5r.so"
         RPATH "\$ORIGIN")
  endif()
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE SHARED_LIBRARY FILES "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/localBuilds/linux-x64-cuda-6u553c5r6wgv6uc3b523w6g491l48j5j5z53/bin/libggml.cuda.v0.9.0.6u553c5r.so")
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libggml.cuda.v0.9.0.6u553c5r.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libggml.cuda.v0.9.0.6u553c5r.so")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libggml.cuda.v0.9.0.6u553c5r.so"
         OLD_RPATH "\$ORIGIN:"
         NEW_RPATH "\$ORIGIN")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libggml.cuda.v0.9.0.6u553c5r.so")
    endif()
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include" TYPE FILE FILES
    "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/llama.cpp/ggml/include/ggml.h"
    "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/llama.cpp/ggml/include/ggml-cpu.h"
    "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/llama.cpp/ggml/include/ggml-alloc.h"
    "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/llama.cpp/ggml/include/ggml-backend.h"
    "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/llama.cpp/ggml/include/ggml-blas.h"
    "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/llama.cpp/ggml/include/ggml-cann.h"
    "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/llama.cpp/ggml/include/ggml-cpp.h"
    "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/llama.cpp/ggml/include/ggml-cuda.h"
    "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/llama.cpp/ggml/include/ggml-opt.h"
    "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/llama.cpp/ggml/include/ggml-metal.h"
    "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/llama.cpp/ggml/include/ggml-rpc.h"
    "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/llama.cpp/ggml/include/ggml-virtgpu.h"
    "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/llama.cpp/ggml/include/ggml-sycl.h"
    "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/llama.cpp/ggml/include/ggml-vulkan.h"
    "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/llama.cpp/ggml/include/ggml-webgpu.h"
    "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/llama.cpp/ggml/include/ggml-zendnn.h"
    "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/llama.cpp/ggml/include/ggml-openvino.h"
    "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/llama.cpp/ggml/include/gguf.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libggml-base.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libggml-base.so")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libggml-base.so"
         RPATH "\$ORIGIN")
  endif()
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE SHARED_LIBRARY FILES "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/localBuilds/linux-x64-cuda-6u553c5r6wgv6uc3b523w6g491l48j5j5z53/bin/libggml-base.so")
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libggml-base.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libggml-base.so")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libggml-base.so"
         OLD_RPATH "\$ORIGIN:"
         NEW_RPATH "\$ORIGIN")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libggml-base.so")
    endif()
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib/cmake/ggml" TYPE FILE FILES
    "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/localBuilds/linux-x64-cuda-6u553c5r6wgv6uc3b523w6g491l48j5j5z53/llama.cpp/ggml/ggml-config.cmake"
    "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/localBuilds/linux-x64-cuda-6u553c5r6wgv6uc3b523w6g491l48j5j5z53/llama.cpp/ggml/ggml-config-version.cmake"
    )
endif()

string(REPLACE ";" "\n" CMAKE_INSTALL_MANIFEST_CONTENT
       "${CMAKE_INSTALL_MANIFEST_FILES}")
if(CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/kaggle/working/motion_video/node_modules/node-llama-cpp/llama/localBuilds/linux-x64-cuda-6u553c5r6wgv6uc3b523w6g491l48j5j5z53/llama.cpp/ggml/install_local_manifest.txt"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
